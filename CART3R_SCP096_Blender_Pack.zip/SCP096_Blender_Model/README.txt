# SCP-096-inspired Blender model

This is a stylized, emaciated humanoid fan model inspired by SCP-096.

## Files
- `SCP096_Emaciated_Humanoid.obj` — 3D mesh, importable into Blender.
- `Generate_SCP096_in_Blender.py` — creates a scene of separate editable Blender objects, materials, camera and lights.
- `README.txt` — these instructions.

## Import the OBJ
1. Open Blender.
2. Choose **File → Import → Wavefront (.obj)**.
3. Select `SCP096_Emaciated_Humanoid.obj`.
4. Adjust scale or materials as desired.

## Generate an editable Blender scene
1. Open Blender and switch to the **Scripting** workspace.
2. Open `Generate_SCP096_in_Blender.py`.
3. Click **Run Script**.
4. Use **File → Save As** to save your `.blend` project.

The generator builds separate mesh objects for the body parts, fingers, toes, facial details, floor, camera and lights. It is a stylized base mesh rather than a fully rigged or production-sculpted character.
