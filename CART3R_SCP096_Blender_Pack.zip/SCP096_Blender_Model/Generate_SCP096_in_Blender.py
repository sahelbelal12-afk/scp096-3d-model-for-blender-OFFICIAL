# CART3R / SCP-096-inspired Blender model generator
# Run inside Blender: Scripting workspace > Open > Run Script.
# Creates an editable, stylized emaciated humanoid fan model.
import bpy, math
from mathutils import Vector

# Clear scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def mat(name, color, roughness=0.82):
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*color,1)
    m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value=(*color,1)
    bs.inputs["Roughness"].default_value=roughness
    return m

skin=mat("Pale ash skin",(0.68,0.63,0.56))
shadow=mat("Deep creases",(0.16,0.11,0.10))
dark=mat("Eye sockets",(0.018,0.012,0.014))
nail=mat("Ivory nails",(0.82,0.77,0.68))

def uv(name, loc, scale, material, seg=24, rings=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=seg, ring_count=rings, location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(material)
    for p in o.data.polygons: p.use_smooth=True
    return o

def bone(name, a, b, radius_a, radius_b, material, verts=16):
    a,b=Vector(a),Vector(b); d=b-a
    mid=(a+b)/2
    bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=radius_a, radius2=radius_b, depth=d.length, location=mid)
    o=bpy.context.object; o.name=name
    o.rotation_mode='QUATERNION'; o.rotation_quaternion=d.to_track_quat('Z','Y')
    o.data.materials.append(material)
    for p in o.data.polygons: p.use_smooth=True
    uv(name+"_jointA",a,(radius_a,)*3,material,12,8)
    uv(name+"_jointB",b,(radius_b,)*3,material,12,8)
    return o

# Core torso and head
uv("Pelvis",(0,0,3.15),(.48,.30,.52),skin)
uv("Abdomen",(0,.015,3.78),(.43,.29,.75),skin)
uv("Ribcage",(0,-.015,4.45),(.62,.34,.67),skin)
uv("Shoulders",(0,.015,4.88),(.72,.30,.25),skin)
uv("Neck",(0,.02,5.20),(.19,.20,.43),skin)
uv("Elongated skull",(0,-.12,5.75),(.34,.31,.56),skin)
uv("Jaw",(0,-.20,5.43),(.25,.25,.28),skin)
uv("Left eye socket",(-.145,-.405,5.82),(.075,.025,.045),dark)
uv("Right eye socket",(.145,-.405,5.82),(.075,.025,.045),dark)
uv("Mouth crease",(0,-.438,5.55),(.13,.018,.025),shadow)

# Extremely long arms and fingers
for s,label in [(-1,"L"),(1,"R")]:
    shoulder=(s*.62,0,4.82); elbow=(s*.91,-.015,3.95)
    wrist=(s*1.03,-.10,2.93); palm=(s*1.06,-.13,2.66)
    bone("Upper arm "+label,shoulder,elbow,.17,.12,skin)
    bone("Forearm "+label,elbow,wrist,.12,.075,skin)
    uv("Palm "+label,palm,(.12,.075,.20),skin)
    for i,spread in enumerate([-.12,-.04,.04,.12]):
        start=(s*1.06+spread,-.15,2.56)
        end=(s*1.06+spread*1.45,-.17,2.15-(.06 if i in (0,3) else 0))
        bone("Finger "+label+str(i+1),start,end,.027,.018,skin,10)
        uv("Nail "+label+str(i+1),(end[0],end[1]-.012,end[2]-.025),(.018,.012,.035),nail,12,8)
    bone("Thumb "+label,(s*1.0,-.14,2.68),(s*.84,-.18,2.48),.045,.025,skin)

# Long legs and feet
for s,label in [(-1,"L"),(1,"R")]:
    hip=(s*.27,0,3.05); knee=(s*.34,-.02,1.72); ankle=(s*.38,-.10,.38)
    bone("Thigh "+label,hip,knee,.22,.13,skin)
    bone("Shin "+label,knee,ankle,.13,.085,skin)
    uv("Foot "+label,(s*.40,-.28,.19),(.15,.34,.16),skin)
    for j in range(3):
        x=s*.40+(j-1)*.075
        uv("Toe "+label+str(j),(x,-.53,.13),(.045,.13,.07),skin,12,8)

# Rib definition
for z in [4.15,4.34,4.53,4.70]:
    for s in [-1,1]:
        o=uv("Rib detail",(s*.20,-.305,z),(.24,.018,.045),shadow,16,8)
        o.rotation_euler[1]=s*.22

# Ground plane for a ready-to-view scene
ground=mat("Ground",(0.035,0.03,0.032))
bpy.ops.mesh.primitive_plane_add(size=200, location=(0,0,0))
plane=bpy.context.object; plane.name="Ground"; plane.data.materials.append(ground)
# Camera and lighting
bpy.ops.object.camera_add(location=(8,-13,6.2))
cam=bpy.context.object; cam.name="Portrait Camera"
cam.rotation_euler=(Vector((0,0,2.9))-cam.location).to_track_quat('-Z','Y').to_euler()
cam.data.lens=55; bpy.context.scene.camera=cam
for name,loc,power,size in [("Key", (4,-6,9),1100,5),("Fill",(-5,-3,5),650,4),("Rim",(1,4,7),1300,3)]:
    bpy.ops.object.light_add(type='AREA', location=loc)
    l=bpy.context.object; l.name=name; l.data.energy=power; l.data.shape='DISK'; l.data.size=size
    l.rotation_euler=(Vector((0,0,3))-l.location).to_track_quat('-Z','Y').to_euler()

# Viewport framing and render setup
scene=bpy.context.scene
scene.render.engine='BLENDER_EEVEE_NEXT'
scene.render.resolution_x=900; scene.render.resolution_y=900; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.world.color=(0.025,0.02,0.025)
bpy.ops.object.select_all(action='DESELECT')
bpy.context.view_layer.objects.active=None
print("CART3R SCP-096-inspired model created. Save the project as a .blend file.")
